class Contato {
  int? id;
  String nome;
  String telefone;
  String email;
  double valorReal;
  double valorDolar;
  double valorEuro;

  Contato({
    this.id,
    required this.nome,
    required this.telefone,
    required this.email,
    required this.valorReal,
    required this.valorDolar,
    required this.valorEuro,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nome': nome,
      'telefone': telefone,
      'email': email,
      'valor_real': valorReal,
      'valor_dolar': valorDolar,
      'valor_euro': valorEuro,
    };
  }

  factory Contato.fromMap(Map<String, dynamic> map) {
    return Contato(
      id: map['id'],
      nome: map['nome'],
      telefone: map['telefone'],
      email: map['email'],
      valorReal: map['valor_real'],
      valorDolar: map['valor_dolar'],
      valorEuro: map['valor_euro'],
    );
  }
}
