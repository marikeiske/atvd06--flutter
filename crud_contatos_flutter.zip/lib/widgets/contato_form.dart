import 'package:flutter/material.dart';
import '../models/contato.dart';
import '../services/api_service.dart';
import '../services/database_service.dart';

class ContatoForm extends StatefulWidget {
  final Contato? contato;
  final VoidCallback aoSalvar;

  const ContatoForm({super.key, this.contato, required this.aoSalvar});

  @override
  State<ContatoForm> createState() => _ContatoFormState();
}

class _ContatoFormState extends State<ContatoForm> {
  final _formKey = GlobalKey<FormState>();
  String nome = '';
  String telefone = '';
  String email = '';
  double valorReal = 0;

  @override
  void initState() {
    super.initState();
    if (widget.contato != null) {
      nome = widget.contato!.nome;
      telefone = widget.contato!.telefone;
      email = widget.contato!.email;
      valorReal = widget.contato!.valorReal;
    }
  }

  void salvar() async {
    if (_formKey.currentState!.validate()) {
      final cotacoes = await ApiService.getCotacoes();
      final valorDolar = valorReal / cotacoes['USD']!;
      final valorEuro = valorReal / cotacoes['EUR']!;

      final novo = Contato(
        id: widget.contato?.id,
        nome: nome,
        telefone: telefone,
        email: email,
        valorReal: valorReal,
        valorDolar: valorDolar,
        valorEuro: valorEuro,
      );

      if (widget.contato == null) {
        await DatabaseService().insertContato(novo);
      } else {
        await DatabaseService().updateContato(novo);
      }

      widget.aoSalvar();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: ListView(
          shrinkWrap: true,
          children: [
            TextFormField(
              initialValue: nome,
              decoration: InputDecoration(labelText: 'Nome'),
              onChanged: (val) => nome = val,
              validator: (val) => val!.isEmpty ? 'Preencha o nome' : null,
            ),
            TextFormField(
              initialValue: telefone,
              decoration: InputDecoration(labelText: 'Telefone'),
              onChanged: (val) => telefone = val,
            ),
            TextFormField(
              initialValue: email,
              decoration: InputDecoration(labelText: 'Email'),
              onChanged: (val) => email = val,
            ),
            TextFormField(
              initialValue: valorReal.toString(),
              decoration: InputDecoration(labelText: 'Valor (R\$)'),
              keyboardType: TextInputType.number,
              onChanged: (val) => valorReal = double.tryParse(val) ?? 0,
            ),
            SizedBox(height: 12),
            ElevatedButton(onPressed: salvar, child: Text('Salvar'))
          ],
        ),
      ),
    );
  }
}
