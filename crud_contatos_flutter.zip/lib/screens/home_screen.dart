import 'package:flutter/material.dart';
import '../models/contato.dart';
import '../services/database_service.dart';
import '../widgets/contato_form.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Contato> contatos = [];

  void carregarContatos() async {
    contatos = await DatabaseService().getContatos();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    carregarContatos();
  }

  void abrirFormulario([Contato? contato]) {
    showModalBottomSheet(
      context: context,
      builder: (_) => ContatoForm(
        contato: contato,
        aoSalvar: () {
          carregarContatos();
          Navigator.of(context).pop();
        },
      ),
    );
  }

  void deletar(int id) async {
    await DatabaseService().deleteContato(id);
    carregarContatos();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Contatos")),
      body: ListView.builder(
        itemCount: contatos.length,
        itemBuilder: (_, i) {
          final c = contatos[i];
          return ListTile(
            title: Text(c.nome),
            subtitle: Text(c.email),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(onPressed: () => abrirFormulario(c), icon: Icon(Icons.edit)),
                IconButton(onPressed: () => deletar(c.id!), icon: Icon(Icons.delete, color: Colors.red)),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => abrirFormulario(),
        child: Icon(Icons.add),
      ),
    );
  }
}
