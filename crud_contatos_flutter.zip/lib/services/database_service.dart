import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/contato.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;
  DatabaseService._internal();

  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'contatos.db');

    return openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE contatos (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nome TEXT,
          telefone TEXT,
          email TEXT,
          valor_real REAL,
          valor_dolar REAL,
          valor_euro REAL
        )
      ''');
    });
  }

  Future<int> insertContato(Contato contato) async {
    final database = await db;
    return await database.insert('contatos', contato.toMap());
  }

  Future<List<Contato>> getContatos() async {
    final database = await db;
    final maps = await database.query('contatos');
    return maps.map((e) => Contato.fromMap(e)).toList();
  }

  Future<int> updateContato(Contato contato) async {
    final database = await db;
    return await database.update(
      'contatos',
      contato.toMap(),
      where: 'id = ?',
      whereArgs: [contato.id],
    );
  }

  Future<int> deleteContato(int id) async {
    final database = await db;
    return await database.delete('contatos', where: 'id = ?', whereArgs: [id]);
  }
}
