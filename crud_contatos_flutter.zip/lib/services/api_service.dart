import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  static Future<Map<String, double>> getCotacoes() async {
    final uri = Uri.parse('https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL');
    final res = await http.get(uri);

    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      final usd = double.parse(data['USDBRL']['bid']);
      final eur = double.parse(data['EURBRL']['bid']);
      return {
        'USD': usd,
        'EUR': eur,
      };
    } else {
      throw Exception('Erro ao buscar cotações');
    }
  }
}
